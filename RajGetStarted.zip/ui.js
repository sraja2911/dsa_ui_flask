scatterData = [
    { "a": 1, "d": 6 },
    { "a": 3, "d": 3 },
    { "a": 6, "d": 8 },
    { "a": 10, "d": 6 },
    { "a": 13, "d": 11 },
    { "a": 16, "d": 5 },
    { "a": 19, "d": 14 }
];


config = {}
config.BASE_URL = "http://candygram.neurology.emory.edu:8080/api/v1"


thumbHeight = 200;

rajsFirstDataView = {
    "template": "<br>#name# <img src='" + config.BASE_URL + "/item/#_id#/tiles/thumbnail' >",
    "view": "dataview",
    "url": "http://candygram.neurology.emory.edu:8080/api/v1/item?folderId=5bd2222ee62914004e463a54&limit=50&sort=lowerName&sortdir=1&height=" + thumbHeight,
    type: {
        width: 261,
        height: 300
    },

    "on": { 'onItemClick': function(id) { 
    			webix.message(id)
    			item = this.getItem(id);
    			console.log(item);

    			 } },
    "select": true
}


webix.ready(function() {
    webix.ui({
        "rows": [{
                "template": "Raj PutsHisHeaderHere",
                "height": 50,
                "view": "template"
            },
            {
                "cols": [{
                    "type": "line",
                    "cols": [{
                        "type": "line",
                        "cols": [{
                            "type": "line",
                            "cols": [
                                rajsFirstDataView,
                                {
                                    "data": scatterData,
                                    "type": "scatter",
                                    "xValue": "#a#",
                                    "value": "#d#",

                                    "view": "chart"
                                }
                            ]
                        }]
                    }]
                }]
            },
            {
                "template": "Footer ",
                "height": 50,
                "view": "template"
            }
        ]
    })
});